	package code;
	
	import java.util.*;
	
	public class WaterSortSearch extends GenericSearch {
	    private static Map<String, Integer> actionCosts;
	
	    public WaterSortSearch(Map<String, Integer> actionCosts) {
	        if (actionCosts != null) {
	            WaterSortSearch.actionCosts = actionCosts;
	        } else {
	            WaterSortSearch.actionCosts = new HashMap<>(); 
	        }
	    }
	
	
	    
	    public static List<String> getActions(String state) {
	        List<String> actions = new ArrayList<>();
	        String[] parts = state.split(";");
	        int numBottles = Integer.parseInt(parts[0]);
	        int bottleCapacity = Integer.parseInt(parts[1]);
	
	        List<Bottle> bottles = parseBottles(parts, numBottles, bottleCapacity);
	
	        for (int i = 0; i < numBottles; i++) {
	            for (int j = 0; j < numBottles; j++) {
	                if (i != j && bottles.get(i).canPourInto(bottles.get(j))) {
	                    String action = new Action(i, j).toString();
	                    actions.add(action);
	                    System.out.println("Valid Action: " + action); 
	                }
	            }
	        }
	        return actions;
	    }
	
	
	
	
	   public static boolean goalTest(String state) {
	    String[] parts = state.split(";");
	    int numBottles = Integer.parseInt(parts[0]);
	    int bottleCapacity = Integer.parseInt(parts[1]);
	
	    List<Bottle> bottles = parseBottles(parts, numBottles, bottleCapacity);
	
	    Set<String> uniqueColors = new HashSet<>();
	    for (Bottle bottle : bottles) {
	        if (!bottle.isEmpty() && !bottle.isUniform()) {
	            System.out.println("Bottle not uniform: " + bottle);
	            return false;
	        }
	        if (!bottle.isEmpty()) {
	            String topColor = bottle.layers.get(bottle.getTopIndex());
	            if (!uniqueColors.add(topColor)) {
	                System.out.println("Color " + topColor + " is spread across multiple bottles.");
	                return false;
	            }
	        }
	    }
	    
	    // If all bottles are uniform or empty, goal state is achieved
	    System.out.println("Goal state achieved for: " + state);
	    return true;
	}
	
	 // Depth-First Search 
	private static String depthFirstSearch(String initialState, boolean visualize) {
	    Stack<Node> frontier = new Stack<>();
	    Set<String> explored = new HashSet<>();
	    int nodesExpanded = 0;
	
	    Node root = new Node(initialState, null, null, 0);
	    frontier.push(root);
	    explored.add(root.state);
	
	    while (!frontier.isEmpty()) {
	        Node node = frontier.pop();
	        nodesExpanded++;
	
	        System.out.println("Expanding state: " + node.state);
	
	        // check goal achieved
	        if (goalTest(node.state)) {
	            System.out.println("Goal achieved after expanding " + nodesExpanded + " nodes.");
	            return constructSolution(node, nodesExpanded);
	        }
	
	        for (String action : getActions(node.state)) {
	            String NEWSTATE = applyAction(node.state, action);
	            String newState = NEWSTATE.split(":")[0];
	            int cost = Integer.parseInt(NEWSTATE.split(":")[1]);
	
	            //backtracking
	            if (node.action != null && isReverseAction(node.action, action)) {
	                continue;
	            }
	
	            if (!explored.contains(newState)) {
	                Node child = new Node(newState, node, action, node.pathCost + cost);
	                explored.add(newState);
	                frontier.push(child);
	
	                System.out.println("Adding state to frontier: " + newState);
	
	                if (visualize) {
	                    System.out.println("Current State: " + newState);
	                }
	            }
	        }
	    }
	
	    System.out.println("No solution found after expanding " + nodesExpanded + " nodes.");
	    return "NOSOLUTION";
	}
	
	
	private static boolean isReverseAction(String prevAction, String currentAction) {
	    String[] prevParts = prevAction.split("_");
	    String[] currParts = currentAction.split("_");
	
	    boolean isReverse = prevParts[1].equals(currParts[2]) && prevParts[2].equals(currParts[1]);
	    if (isReverse) {
	        System.out.println("Skipping reverse action: " + currentAction + " (reverses " + prevAction + ")");
	    }
	
	    return isReverse;
	}
	
	
	 //IDS
	    private static String iterativeDeepeningSearch(String initialState, boolean visualize) {
	        int depthLimit = 0;
	        int nodesExpanded = 0;
	
	        while (true) {
	            String result = depthLimitedSearch(initialState, depthLimit, visualize, nodesExpanded);
	            if (!result.equals("CUTOFF")) {
	                return result;
	            }
	            depthLimit++;  
	        }
	    }
	
	    //used in IDS
	    private static String depthLimitedSearch(String initialState, int limit, boolean visualize, int nodesExpanded) {
	        Stack<Node> frontier = new Stack<>();
	        Set<String> explored = new HashSet<>();
	
	        Node root = new Node(initialState, null, null, 0);
	        frontier.push(root);
	
	        while (!frontier.isEmpty()) {
	            Node node = frontier.pop();
	            nodesExpanded++;
	
	            if (goalTest(node.state)) {
	                return constructSolution(node, nodesExpanded);  
	            }
	
	            if (node.pathCost < limit) {  
	                explored.add(node.state);
	
	                for (String action : getActions(node.state)) {
	                	String NEWSTATE = applyAction(node.state, action);
	                    String newState = NEWSTATE.split(":")[0];
	                    int cost = Integer.parseInt(NEWSTATE.split(":")[1]);
	                    if (!explored.contains(newState) && !stateInStack(frontier, newState)) {
	                        Node child = new Node(newState, node, action, node.pathCost + cost);
	                        frontier.push(child);
	
	                        if (visualize) {
	                            System.out.println("Current State: " + newState);
	                        }
	                    }
	                }
	            }
	        }
	
	        return "CUTOFF";  
	    }
	
	    //solve
	    public static String solve(String initialState, String strategy, boolean visualize) {
	        long startTime = System.currentTimeMillis();
	        long startMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
	        String result = "";  // Result from the selected search algorithm
	
	        if (strategy.equals("BF")) {
	            result = breadthFirstSearch(initialState, visualize);
	        } else if (strategy.equals("DF")) {
	            result = depthFirstSearch(initialState, visualize);
	        } else if (strategy.equals("UC")) {
	            result = uniformCostSearch(initialState, visualize);
	        } else if (strategy.equals("ID")) {
	            result = iterativeDeepeningSearch(initialState, visualize);  // Add IDS support
	        } else if (strategy.startsWith("GR")) {
	            int heuristicOption = Integer.parseInt(strategy.substring(2));  // Extract heuristic option (GR1 or GR2)
	            result = greedySearch(initialState, visualize, heuristicOption);
	        } else if (strategy.startsWith("AS")) {
	            int heuristicOption = Integer.parseInt(strategy.substring(2));  // Extract heuristic option (AS1 or AS2)
	            result = aStarSearch(initialState, visualize, heuristicOption);
	        }
	
	        long endTime = System.currentTimeMillis();
	        long endMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
	
	        System.out.println("Time taken: " + (endTime - startTime) + " ms");
	        System.out.println("Memory used: " + (endMemory - startMemory) + " bytes");
	
	        return result;
	    }
	
	    //BFS
	   private static String breadthFirstSearch(String initialState, boolean visualize) {
	    Queue<Node> frontier = new LinkedList<>();
	    Set<String> visited = new HashSet<>();  
	    int nodesExpanded = 0; 
	
	    Node root = new Node(initialState, null, null, 0);
	    frontier.add(root);
	    visited.add(root.state);  
	
	    while (!frontier.isEmpty()) {
	        Node node = frontier.poll();  
	        nodesExpanded++;
	
	        if (goalTest(node.state)) {
	            return constructSolution(node, nodesExpanded); 
	        }
	        
	        for (String action : getActions(node.state)) {
	            String NEWSTATE = applyAction(node.state, action);
	            String newState = NEWSTATE.split(":")[0];
	            int cost = Integer.parseInt(NEWSTATE.split(":")[1]);
	
	            if (!visited.contains(newState)) {
	                Node child = new Node(newState, node, action, node.pathCost + cost);
	                frontier.add(child); 
	                visited.add(newState);  
	
	                if (visualize) {
	                    System.out.println("Current State: " + newState + " with path cost: " + child.pathCost);
	                }
	            }
	        }
	    }
	
	    return "NOSOLUTION";  
	}
	
	    //UCS
	    private static String uniformCostSearch(String initialState, boolean visualize) {
	        PriorityQueue<Node> frontier = new PriorityQueue<>(Comparator.comparingInt(node -> node.pathCost));
	        Set<String> explored = new HashSet<>();
	        int nodesExpanded = 0;
	
	        Node root = new Node(initialState, null, null, 0);
	        frontier.add(root);
	
	        while (!frontier.isEmpty()) {
	            Node node = frontier.poll();
	            nodesExpanded++;
	
	            if (goalTest(node.state)) {
	                return constructSolution(node, nodesExpanded);
	            }
	
	            explored.add(node.state);
	
	            for (String action : getActions(node.state)) {
	            	String NEWSTATE = applyAction(node.state, action);
	                String newState = NEWSTATE.split(":")[0];
	                int cost = Integer.parseInt(NEWSTATE.split(":")[1]);
	
	                if (!explored.contains(newState)) {
	                    Node child = new Node(newState, node, action, node.pathCost + cost);
	                    frontier.add(child);
	
	                    if (visualize) {
	                        System.out.println("Current State: " + newState + " with path cost: " + child.pathCost);
	                    }
	                }
	            }
	        }
	
	        return "NOSOLUTION";
	    }
	
	    // Greedy Search
	    private static String greedySearch(String initialState, boolean visualize, int heuristicOption) {
	        PriorityQueue<Node> frontier = new PriorityQueue<>(Comparator.comparingInt(node -> heuristic(node, heuristicOption)));
	        Set<String> explored = new HashSet<>();
	        int nodesExpanded = 0;
	
	        Node root = new Node(initialState, null, null, 0);
	        frontier.add(root);
	
	        while (!frontier.isEmpty()) {
	            Node node = frontier.poll();
	            nodesExpanded++;
	
	            if (goalTest(node.state)) {
	                return constructSolution(node, nodesExpanded);
	            }
	
	            explored.add(node.state);
	
	            for (String action : getActions(node.state)) {
	            	String NEWSTATE = applyAction(node.state, action);
	                String newState = NEWSTATE.split(":")[0];
	                int cost = Integer.parseInt(NEWSTATE.split(":")[1]);
	
	                if (!explored.contains(newState)) {
	                    Node child = new Node(newState, node, action, node.pathCost + cost);
	                    frontier.add(child);
	
	                    if (visualize) {
	                        System.out.println("Current State: " + newState);
	                    }
	                }
	            }
	        }
	
	        return "NOSOLUTION";
	    }
	
	    //A* Search
	    private static String aStarSearch(String initialState, boolean visualize, int heuristicOption) {
	        PriorityQueue<Node> frontier = new PriorityQueue<>(Comparator.comparingInt(node -> totalCost(node, heuristicOption)));
	        Set<String> explored = new HashSet<>();
	        int nodesExpanded = 0;
	
	        Node root = new Node(initialState, null, null, 0);
	        frontier.add(root);
	
	        while (!frontier.isEmpty()) {
	            Node node = frontier.poll();
	            nodesExpanded++;
	
	            if (goalTest(node.state)) {
	                return constructSolution(node, nodesExpanded);
	            }
	
	            explored.add(node.state);
	
	            for (String action : getActions(node.state)) {
	            	String NEWSTATE = applyAction(node.state, action);
	                String newState = NEWSTATE.split(":")[0];
	                int cost = Integer.parseInt(NEWSTATE.split(":")[1]);
	
	                if (!explored.contains(newState)) {
	                    Node child = new Node(newState, node, action, node.pathCost + cost);
	                    frontier.add(child);
	
	                    if (visualize) {
	                        System.out.println("Current State: " + newState);
	                    }
	                }
	            }
	        }
	
	        return "NOSOLUTION";
	    }
	
	    //heuristic function
	    private static int heuristic(Node node, int heuristicOption) {
	        if (heuristicOption == 1) {
	            return heuristic1(node); 
	        } else if (heuristicOption == 2) {
	            return heuristic2(node); 
	        }
	        return Integer.MAX_VALUE; 
	    }
	
	    private static int heuristic1(Node node) {
	        int unsortedBottles = 0;
	        String[] parts = node.state.split(";");
	        int numBottles = Integer.parseInt(parts[0]);
	        int bottleCapacity = Integer.parseInt(parts[1]);
	
	        List<Bottle> bottles = parseBottles(parts, numBottles, bottleCapacity);
	
	        for (Bottle bottle : bottles) {
	            if (!bottle.isEmpty() && !bottle.isUniform()) {
	                unsortedBottles++; 
	            }
	        }
	
	        return unsortedBottles;
	    }
	
	    private static int heuristic2(Node node) {
	        int misplacedLayers = 0;
	        String[] parts = node.state.split(";");
	        int numBottles = Integer.parseInt(parts[0]);
	        int bottleCapacity = Integer.parseInt(parts[1]);
	
	        List<Bottle> bottles = parseBottles(parts, numBottles, bottleCapacity);
	
	        for (Bottle bottle : bottles) {
	            if (!bottle.isEmpty()) {
	                String topColor = bottle.layers.get(bottle.getTopIndex());
	                for (String layer : bottle.layers) {
	                    if (!layer.equals("e") && !layer.equals(topColor)) {
	                        misplacedLayers++;  
	                    }
	                }
	            }
	        }
	
	        return misplacedLayers;
	    }
	
	    // A* f(n) = g(n) + h(n)
	    private static int totalCost(Node node, int heuristicOption) {
	        return node.pathCost + heuristic(node, heuristicOption);
	    }
	
	  private static String applyAction(String state, String action) {
	    System.out.println("Applying action: " + action + " on state: " + state);
	    String[] parts = state.split(";");
	    int numBottles = Integer.parseInt(parts[0]);
	    int bottleCapacity = Integer.parseInt(parts[1]);
	    List<Bottle> bottles = parseBottles(parts, numBottles, bottleCapacity);
	    int cost = 0;
	    String[] actionParts = action.split("_");
	    int from = Integer.parseInt(actionParts[1]);
	    int to = Integer.parseInt(actionParts[2]);
	
	    if (bottles.get(from).canPourInto(bottles.get(to))) {
	        cost = bottles.get(from).pourInto(bottles.get(to));
	    } else {
	        System.out.println("Invalid action: " + action);
	    }
	
	    String newState = numBottles + ";" + bottleCapacity + ";" + bottlesToStateString(bottles) + ":" + cost;
	    System.out.println("New State after action " + action + ": " + newState);  // Debugging output
	    return newState;
	}
	
	  
	  
	    private static String bottlesToStateString(List<Bottle> bottles) {
	        StringBuilder state = new StringBuilder();
	        for (Bottle bottle : bottles) {
	            state.append(bottle.toString()).append(";");
	        }
	        return state.toString();
	    }
	
	
	    private static List<Bottle> parseBottles(String[] parts, int numBottles, int bottleCapacity) {
	        List<Bottle> bottles = new ArrayList<>();
	        for (int i = 0; i < numBottles; i++) {
	            List<String> layers = Arrays.asList(parts[i + 2].split(","));
	            bottles.add(new Bottle(layers, bottleCapacity));
	        }
	        return bottles;
	    }
	
	
	    private static boolean stateInStack(Stack<Node> frontier, String state) {
	        for (Node node : frontier) {
	            if (node.state.equals(state)) {
	                return true;
	            }
	        }
	        return false;
	    }
	
	
	    private static String constructSolution(Node node, int nodesExpanded) {
	        StringBuilder solution = new StringBuilder();
	        int pathCost = node.pathCost;  
	
	        while (node != null && node.action != null) {
	            solution.insert(0, node.action + (solution.length() > 0 ? "," : "")); 
	            node = node.parent;
	        }
	
	        System.out.println("Solution found: " + solution.toString());
	        return solution.toString() + ";" + pathCost + ";" + nodesExpanded;
	    }
	
	}