package code;

import java.util.Comparator;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;

public abstract class GenericSearch {

	public static String genericSearch(String initialState, Function<Node, Boolean> goalTest, 
            Function<Node, List<String>> getActions, 
            BiFunction<String, String, String> applyAction, 
            Queue<Node> frontier, Set<String> explored, 
            Comparator<Node> strategyComparator, boolean visualize) {

			Node root = new Node(initialState, null, null, 0);
			frontier.add(root);
			explored.add(root.state);
			int nodesExpanded = 0;
			
			while (!frontier.isEmpty()) {
			Node node = frontier.poll();
			nodesExpanded++;
						
			// Get possible actions and explore
			for (String action : getActions.apply(node)) {
			String newState = applyAction.apply(node.state, action).split(":")[0];
			int cost = Integer.parseInt(applyAction.apply(node.state, action).split(":")[1]);
			
			if (!explored.contains(newState)) {
			Node child = new Node(newState, node, action, node.pathCost + cost);
			explored.add(newState);
			frontier.add(child);
			
			if (visualize) {
			System.out.println("Current State: " + newState);
			}
		}
	}
}
			
			return "NOSOLUTION";
		}
			
}
