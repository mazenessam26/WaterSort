package code;

public abstract class GenericSearch {
   

    
}