package code;


public class Node {
    public String state;  
    public Node parent;    
    public String action; 
    public int pathCost;   

    public Node(String state, Node parent, String action, int pathCost) {
        this.state = state;
        this.parent = parent;
        this.action = action;
        this.pathCost = pathCost;
    }
}