package code;

import java.util.*;

public class Bottle {
    List<String> layers;
    private int capacity;

    public Bottle(List<String> layers, int capacity) {
        this.layers = layers;
        this.capacity = capacity;
    }

    public boolean isFull() {
        return getTopIndex() == 0;
    }

    public boolean isEmpty() {
        return getTopIndex() == -1;
    }

    public int getTopIndex() {
        for (int i = 0; i < layers.size(); i++) {
            if (!layers.get(i).equals("e")) {
                return i; 
            }
        }
        return -1; 
    }

    public boolean isUniform() {
        String color = null;
        for (String layer : layers) {
            if (!layer.equals("e")) { 
                if (color == null) {
                    color = layer;
                } else if (!color.equals(layer)) {
                    return false; 
                }
            }
        }
        return true;
    }

    public boolean canPourInto(Bottle targetBottle) {
        int fromTopIndex = this.getTopIndex();

        if (fromTopIndex == -1 || targetBottle.isFull()) {
            return false;
        }

        //color of the layer we want to pour
        String colorToPour = this.layers.get(fromTopIndex);
        int pourableLayers = 0;
        while (fromTopIndex < capacity && this.layers.get(fromTopIndex).equals(colorToPour)) {
            pourableLayers++;
            fromTopIndex++;
        }

        int availableSpace = targetBottle.getAvailableSpace();

     
        if (targetBottle.isEmpty()) {
            return true; 
        } else if (colorToPour.equals(targetBottle.layers.get(targetBottle.getTopIndex())) && availableSpace > 0) {
        	
        	return pourableLayers <= availableSpace;
        }

        return false; 
    }


    private int countMatchingLayersFromTop(String color) {
        int count = 0;
        int index = getTopIndex();
        while (index < layers.size() && layers.get(index).equals(color)) {
            count++;
            index++;
        }
        return count;
    }



    public int pourInto(Bottle targetBottle) {
        int fromTopIndex = this.getTopIndex();
        if (fromTopIndex == -1 || targetBottle.isFull()) {
            return 0; 
        }

        String colorToPour = this.layers.get(fromTopIndex);
        int pourableLayers = countMatchingLayersFromTop(colorToPour);
        int availableSpace = targetBottle.getAvailableSpace();


        int layersToPour = Math.min(pourableLayers, availableSpace);

        for (int i = 0; i < layersToPour; i++) {
           
            if (targetBottle.isEmpty() || targetBottle.layers.get(targetBottle.getTopIndex()).equals(colorToPour)) {
                targetBottle.addLayer(colorToPour);  
                this.removeTopLayer(); 
            } else {
                break;  
            }
        }

        return layersToPour;  
    }


    private int getAvailableSpace() {
        int filledLayers = (int) layers.stream().filter(layer -> !layer.equals("e")).count();
        return capacity - filledLayers;
    }

    private void addLayer(String color) {
        for (int i = layers.size() - 1; i >= 0; i--) {
            if (layers.get(i).equals("e")) { 
                layers.set(i, color);         
                break;
            }
        }
    }


    private void removeTopLayer() {
        int topIndex = getTopIndex();
        if (topIndex != -1) {
            layers.set(topIndex, "e");
        }
    }


    @Override
    public String toString() {
        return String.join(",", layers);
    }
}